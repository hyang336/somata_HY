"""
Author: Mingjian He <mh1@stanford.edu>

source_loc module contains dynamic source localization code base in SOMATA
"""

from .dmap_em import SourceLocModel  # Source localization model class  # noqa: F401
