from .basic_models import StateSpaceModel, OscillatorModel, AutoRegModel, GeneralSSModel  # noqa: F401
from importlib.metadata import version
__version__ = version('somata')
